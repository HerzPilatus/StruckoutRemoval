# Copyright (c) Facebook, Inc. and its affiliates.

from .evaluator import DensePoseCOCOEvaluator
